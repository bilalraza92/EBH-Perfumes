
const burger = document.getElementById("hamburger");

const list = document.getElementById("navlist");


burger.addEventListener("click", () => {
    

    list.classList.toggle("navlist-active");

});
